export default function Hero() {
  return (
    <section className="hero-section section-wrap">
      <div className="hero-copy">
        <p className="eyebrow">Dedicated to study, language, beauty, and light</p>
        <h1>Enter a living architecture of study.</h1>
        <p className="hero-text">
          LuminaNexus is a digital beit midrash shaped by the Tree of Life — a place where
          Hebrew letters, contemplative learning, sacred art, and technical imagination meet
          in one luminous order.
        </p>

        <div className="hero-actions">
          <a className="button primary" href="#tree">
            Begin the Path
          </a>
          <a className="button secondary" href="#library">
            Enter the 231 Gates
          </a>
        </div>

        <div className="stats-grid">
          <div className="stat-card">
            <strong>10</strong>
            <span>Sefirot gateways</span>
          </div>
          <div className="stat-card">
            <strong>231</strong>
            <span>Letter gates</span>
          </div>
          <div className="stat-card">
            <strong>1</strong>
            <span>Hidden Aleph Olam</span>
          </div>
        </div>
      </div>
    </section>
  )
}
