export default function Header() {
  return (
    <header className="site-header">
      <div className="brand-block">
        <div className="brand-title">LuminaNexus</div>
        <div className="brand-tag">A quiet digital sanctuary</div>
      </div>

      <nav className="site-nav" aria-label="Primary navigation">
        <a href="#tree">The Tree</a>
        <a href="#library">Library</a>
        <a href="#chavruta">Chavruta</a>
        <a href="#ivritcode">IvritCode</a>
        <a href="#support">Support</a>
      </nav>
    </header>
  )
}
