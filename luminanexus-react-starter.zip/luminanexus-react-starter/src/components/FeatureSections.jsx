const features = [
  {
    id: 'library',
    eyebrow: 'Library',
    title: 'A sanctuary for study',
    text: 'LuminaNexus gathers sacred writing, contemplative essays, meditations, diagrams, and exploratory thought into one quiet structure. The library is not merely a collection. It is an ordered field of return.',
  },
  {
    id: 'chavruta',
    eyebrow: 'Chavruta',
    title: 'Ask, study, and dwell',
    text: 'Chavruta should feel immediate. A visitor asks a question, receives a guided path, and sees related themes, letters, and texts without being buried under a complicated interface.',
  },
  {
    id: 'ivritcode',
    eyebrow: 'IvritCode',
    title: 'Where language becomes structure',
    text: 'This is the technical chamber: symbolic computation, Hebrew-rooted architecture, diagrams, and experimental systems shaped with clarity and reverence.',
  },
  {
    id: 'support',
    eyebrow: 'Support the Light',
    title: 'Help keep the sanctuary open',
    text: 'Support LuminaNexus through giving, partnership, and shared work. What is built here is meant to be useful, beautiful, and enduring.',
  },
]

export default function FeatureSections() {
  return (
    <section className="section-wrap feature-grid-wrap">
      {features.map((feature) => (
        <article key={feature.id} id={feature.id} className="feature-panel">
          <p className="eyebrow">{feature.eyebrow}</p>
          <h3>{feature.title}</h3>
          <p>{feature.text}</p>
        </article>
      ))}
    </section>
  )
}
