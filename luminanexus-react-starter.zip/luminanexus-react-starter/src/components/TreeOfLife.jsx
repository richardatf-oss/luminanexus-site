const sefirot = [
  { name: 'Keter', hebrew: 'כתר', subtitle: 'Begin the Path', left: '50%', top: '9%' },
  { name: 'Chokhmah', hebrew: 'חכמה', subtitle: 'Sparks of Insight', left: '28%', top: '22%' },
  { name: 'Binah', hebrew: 'בינה', subtitle: 'Deep Study', left: '72%', top: '22%' },
  { name: 'Chesed', hebrew: 'חסד', subtitle: 'Giving & Support', left: '20%', top: '40%' },
  { name: 'Gevurah', hebrew: 'גבורה', subtitle: 'Precision & Craft', left: '80%', top: '40%' },
  { name: 'Tiferet', hebrew: 'תפארת', subtitle: 'Beauty & Harmony', left: '50%', top: '44%' },
  { name: 'Netzach', hebrew: 'נצח', subtitle: 'Creative Work', left: '28%', top: '64%' },
  { name: 'Hod', hebrew: 'הוד', subtitle: 'Hebrew & Language', left: '72%', top: '64%' },
  { name: 'Yesod', hebrew: 'יסוד', subtitle: 'Chavruta & Connection', left: '50%', top: '79%' },
  { name: 'Malkhut', hebrew: 'מלכות', subtitle: 'Books & Downloads', left: '50%', top: '93%' },
]

const paths = [
  ['50%', '9%', '28%', '22%'],
  ['50%', '9%', '72%', '22%'],
  ['28%', '22%', '50%', '44%'],
  ['72%', '22%', '50%', '44%'],
  ['20%', '40%', '50%', '44%'],
  ['80%', '40%', '50%', '44%'],
  ['50%', '44%', '28%', '64%'],
  ['50%', '44%', '72%', '64%'],
  ['28%', '64%', '50%', '79%'],
  ['72%', '64%', '50%', '79%'],
  ['50%', '79%', '50%', '93%'],
]

export default function TreeOfLife() {
  return (
    <section id="tree" className="section-wrap tree-section">
      <div className="section-heading">
        <p className="eyebrow">The Living Tree</p>
        <h2>Navigation by sacred structure</h2>
        <p>
          Instead of treating LuminaNexus like a standard site menu, this homepage lets people
          move through the sanctuary by way of the sefirot.
        </p>
      </div>

      <div className="tree-frame">
        <svg className="tree-lines" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
          {paths.map(([x1, y1, x2, y2], index) => (
            <line key={index} x1={x1} y1={y1} x2={x2} y2={y2} />
          ))}
        </svg>

        {sefirot.map((node) => (
          <div
            key={node.name}
            className="tree-node"
            style={{ left: node.left, top: node.top }}
          >
            <div className="tree-sphere">
              <div className="tree-name">{node.name}</div>
              <div className="tree-hebrew">{node.hebrew}</div>
            </div>
            <p>{node.subtitle}</p>
          </div>
        ))}

        <div className="aleph-olam">ALEPH OLAM</div>
      </div>
    </section>
  )
}
