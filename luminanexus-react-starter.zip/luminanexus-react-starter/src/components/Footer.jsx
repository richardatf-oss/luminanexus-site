export default function Footer() {
  return (
    <footer className="site-footer">
      <p>LuminaNexus · A quiet digital sanctuary for study, language, beauty, and light.</p>
    </footer>
  )
}
