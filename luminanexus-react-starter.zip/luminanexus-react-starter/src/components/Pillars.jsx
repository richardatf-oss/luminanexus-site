const pillars = [
  {
    title: 'The Celestial Library',
    body: 'Enter the 231 Gates through teachings, meditations, essays, diagrams, and ordered pathways of study.',
  },
  {
    title: 'Chavruta',
    body: 'Ask a question and step into guided study, living conversation, and contemplative return.',
  },
  {
    title: 'IvritCode',
    body: 'Explore Hebrew-rooted computation, symbolic architecture, and experimental technical work.',
  },
  {
    title: 'Daily Spark',
    body: 'Return each day for one Hebrew letter, one verse, one insight, and one small flame of remembrance.',
  },
]

export default function Pillars() {
  return (
    <section className="section-wrap">
      <div className="section-heading narrow">
        <p className="eyebrow">Four Pillars</p>
        <h2>A homepage shaped by return</h2>
        <p>The visitor does not merely browse. The visitor enters, lingers, learns, and returns.</p>
      </div>

      <div className="card-grid">
        {pillars.map((pillar) => (
          <article key={pillar.title} className="content-card">
            <h3>{pillar.title}</h3>
            <p>{pillar.body}</p>
          </article>
        ))}
      </div>
    </section>
  )
}
